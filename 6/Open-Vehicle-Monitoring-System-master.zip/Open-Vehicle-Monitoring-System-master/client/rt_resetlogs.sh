#!/bin/bash

echo "Reset RT-ENG-Log*..."
./cmd.pl 209 99

echo "Done."
