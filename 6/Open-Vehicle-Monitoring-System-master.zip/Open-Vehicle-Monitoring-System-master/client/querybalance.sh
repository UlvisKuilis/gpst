#!/bin/bash
echo "Query SIM account balance..."
./cmd.pl 41 "*100#"
