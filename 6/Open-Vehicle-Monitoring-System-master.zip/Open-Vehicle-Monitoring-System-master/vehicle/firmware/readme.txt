
OVMS Firmware

This is the latest released version of firmware.

V1_production.hex               V1 Hardware Module, production firmware
V2_experimental.hex             V2 Hardware Module, experimental firmware
V2_production.hex               V2 Hardware Module, production firmware
V2_RT_production.hex            V2 Hardware Module, Renault Twizy full firmware
V2_TR_production.hex            V2 Hardware Module, Tesla Roadster full firmware

