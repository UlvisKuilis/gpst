The Geogram ONE is an open source tracking device/development board based off the Arduino platform.

The hardware design and software files are released under CC-SA v3 license.

There are several attributable portions of code that will be listed shortly.